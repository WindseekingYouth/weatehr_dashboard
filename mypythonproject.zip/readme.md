'''
MANNUAL

The readme is to tell you how to use this simple app.

Download form github.com, unlease the zip,
then open and run the main.py in a certain environment.

In the terminal, you can see and use the 127.0.0.1:5000 to run the app
in a web browser.

Make sure u type the city you want to search, 
and the Codes for the representation of names of countries and regions
e.g. "the city you search" = beijing,cn

Push the "search" botton,
the terminal will run for a little while,
then output the outcome with images.
Which can show you current, past, and future's weather reports.

If the outcome went into failure, 
and typpe red chinese letters, 
that means there is something wrong with those .py projects.
you need to check the errors, 
and go to the right part to fix the problems.

As an open project,
feel free to edit it by yourselves.
'''

'''
TIPS:

The time you get is UTC.
Plus you timelag to calculate the correct number in your timezone.

All needed packages with special requirements are packed in.
You will only need to download the packages in the requestment by yourselves.
'''