# app/main.py

from fastapi import FastAPI, Request
import httpx
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse

# 创建 FastAPI 实例
app = FastAPI()

# 设置模板目录
templates = Jinja2Templates(directory="templates")

# OpenWeatherMap API 密钥
API_KEY = "585c05f0e9fafc0aa0ee0e2012beb412"  # 获取到的api密钥
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

# 获取天气信息
async def get_weather(city: str):
    async with httpx.AsyncClient() as client:
        # 构造请求 URL
        url = f"{BASE_URL}?q={city}&appid={API_KEY}&units=metric"
        response = await client.get(url)
        if response.status_code == 200:
            data = response.json()
            return data
        else:
            return None

# 首页，显示天气查询表单
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# 处理天气查询请求
@app.get("/weather", response_class=HTMLResponse)
async def weather(request: Request, city: str):
    data = await get_weather(city)
    if data:
        return templates.TemplateResponse("weather.html", {"request": request, "data": data})
    else:
        return templates.TemplateResponse("error.html", {"request": request})
