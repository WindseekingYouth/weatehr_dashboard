from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import fetch_data
import visualization
import logging
import pandas as pd

app = Flask(__name__)  # 修改为 Flask(__name__)，保证 Flask 实例化正确

# 启用 CORS，允许跨域请求
CORS(app, resources={r"/api/": {"origins": "*"}})  # 修改为 "*" 以允许所有来源的请求

# 配置日志
logging.basicConfig(level=logging.INFO)

@app.route('/')
def index():
    """返回首页"""
    return render_template('index.html')

@app.route('/api/get_weather', methods=['POST'])
def get_weather():
    """获取天气数据"""
    try:
        data = request.get_json()  # 获取 POST 请求中的 JSON 数据
        city_name = data.get('cityName')

        if not city_name:
            logging.warning("未提供城市名称")
            return jsonify({'success': False, 'message': '未提供城市名称'}), 400

        # 获取天气数据
        history_data, current_data, forecast_data =fetch_data.fetch_weather_data('c09f84c8b23339eea6c92eee24427d10', city_name)
        weather_data = fetch_data.process_weather_data(forecast_data,history_data, current_data)
        if weather_data:
            # 可视化数据并返回图像的 base64 编码
            try:
                past_img = visualization.plot_pass(weather_data['past_weather'])
                future_img = visualization.plot_future(weather_data['future_weather'])
                now_img = visualization.plot_now(weather_data['today_weather'])

                logging.info(f"成功获取 {city_name} 的天气数据")
                return jsonify({
                    'success': True, 
                    'weatherData': weather_data,
                    'pastWeatherImage': past_img,
                    'futureWeatherImage': future_img,
                    'todayWeatherImage': now_img
                })
            except KeyError as e:
                # 捕获缺少预期数据的错误
                logging.error(f"天气数据格式错误，缺少必要字段: {str(e)}")
                return jsonify({'success': False, 'message': '天气数据格式错误'}), 500
            except Exception as e:
                # 捕获其他未知的异常
                logging.error(f"处理天气数据时发生错误: {str(e)}")
                return jsonify({'success': False, 'message': '处理天气数据时发生错误'}), 500
        else:
            logging.error(f"获取 {city_name} 天气数据失败：没有返回有效的天气数据")
            return jsonify({'success': False, 'message': '获取天气数据失败'}), 500

    except Exception as e:
        logging.error(f"处理请求时发生错误: {e}")
        return jsonify({'success': False, 'message': '服务器内部错误'}), 500

if __name__ == '__main__':
    app.run(debug=True)
