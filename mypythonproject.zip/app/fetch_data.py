import requests
import pandas as pd
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

def fetch_data(url):
    response = requests.get(url)
    if response.status_code == 200:
        try:
            return response.json()  # Parse JSON data
        except ValueError:
            print("Error: Failed to decode JSON response.")
            return None
    else:
        print(f"Failed to fetch data: {response.status_code}")
        print(f"Error details: {response.text}")
        return None

def fetch_weather_data(api_key, cityName):
    # Get historical weather data
    history_url = f'https://history.openweathermap.org/data/2.5/history/city?q={cityName}&type=hour&appid={api_key}'
    history_data = fetch_data(history_url)


    # Get current weather data
    current_url = f'http://api.openweathermap.org/data/2.5/weather?q={cityName}&appid={api_key}'
    current_data = fetch_data(current_url)


    # Get weather forecast data
    forecast_url = f'http://api.openweathermap.org/data/2.5/forecast?q={cityName}&appid={api_key}'
    forecast_data = fetch_data(forecast_url)


    return history_data, current_data, forecast_data

def parse_weather(entry):
    if entry is None:
        return None
    # Ensure the fields are in the API data
    return {
        'Datetime': pd.to_datetime(entry['dt'], unit='s').normalize(),
        'Temperature (C)': entry['main']['temp'] - 273.15,
        'Humidity (%)': entry['main']['humidity'],
        'Wind Speed (m/s)': entry['wind']['speed'],
        'Weather': entry['weather'][0]['description']
    }

def save_to_csv(data, filename):
    if data is None or len(data) == 0:
        print(f"No data to save for {filename}")
        return
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)

def calculate_daily_stats(forecast_data):
    if forecast_data is None or len(forecast_data) == 0:
        return None
    df_forecast = pd.DataFrame(forecast_data)
    df_forecast['Date'] = df_forecast['Datetime'].dt.date
    daily_stats = df_forecast.groupby('Date').agg({
        'Temperature (C)': ['min', 'max'],
        'Humidity (%)': ['min', 'max'],
        'Wind Speed (m/s)': ['min', 'max']
    })

    daily_stats.columns = ['Min Temperature (C)', 'Max Temperature (C)', 
                            'Min Humidity (%)', 'Max Humidity (%)', 
                            'Min Wind Speed (m/s)', 'Max Wind Speed (m/s)']
    daily_stats.reset_index(inplace=True)

    return daily_stats

def process_weather_data(history_data, current_data, forecast_data):
    # Process historical weather, skipping None values
    history_weather = [parse_weather(entry) for entry in history_data['list']]
    # Process current weather
    current_weather = parse_weather(current_data)
    # Process forecast weather, skipping None values
    forecast_weather = [parse_weather(entry) for entry in forecast_data['list']]

    # Save data to CSV
    save_to_csv(forecast_weather, 'forecast_hourly_weather_data.csv')
    save_to_csv([current_weather], 'current_weather_data.csv')
    save_to_csv(history_weather, 'history_hourly_weather_data.csv')

    # Calculate daily statistics and save
    history_daily_stats = calculate_daily_stats(history_weather)
    save_to_csv(history_daily_stats, 'history_daily_weather_stats.csv')
    forecast_daily_stats = calculate_daily_stats(forecast_weather)
    save_to_csv(forecast_daily_stats, 'forecast_daily_weather_stats.csv')

    return {
        'past_weather': history_weather,
        'future_weather': forecast_weather,
        'today_weather': current_weather
    }
