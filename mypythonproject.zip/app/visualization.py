import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# 假设我们从search.py得到了以上的结构化数据
# 1. 处理过去5天的数据
past_weather_data =pd.read_csv('history_hourly_weather_data,csv')
past_df = pd.DataFrame(past_weather_data)

# 将日期转换为Pandas的datetime格式
past_df['date'] = pd.to_datetime(past_df['date'])

# 2. 处理未来每三个小时的天气数据
future_weather_data = pd.read_csv['forecast_hourly_weather_data.csv']
future_df = pd.DataFrame(future_weather_data)
future_df['date'] = pd.to_datetime(future_df['date'])

# 3. 处理当前天气数据
today_weather_data = pd.read_csv['current_weather_data.csv']
today_df = pd.DataFrame(today_weather_data)

# 将时间列转换为Pandas的datetime格式
today_df['time'] = pd.to_datetime(today_df['time'])

# 1. 过去5天的气温变化 - 折线图和柱状图
fig, axes = plt.subplots(2, 1, figsize=(10, 12))

# 过去5天的折线图
axes[0].plot(past_df['date'], past_df['temp_max'], label='Max Temp (°C)', marker='o')
axes[0].plot(past_df['date'], past_df['temp_min'], label='Min Temp (°C)', marker='o')
axes[0].plot(past_df['date'], past_df['temp_avg'], label='Avg Temp (°C)', marker='o')
axes[0].set_title('Past 5 Days Temperature (°C)')
axes[0].set_xlabel('Date')
axes[0].set_ylabel('Temperature (°C)')
axes[0].legend()

# 过去5天的柱状图
width = 0.2
x = np.arange(len(past_df))
axes[1].bar(x - width, past_df['temp_max'], width, label='Max Temp (°C)', alpha=0.7)
axes[1].bar(x, past_df['temp_min'], width, label='Min Temp (°C)', alpha=0.7)
axes[1].bar(x + width, past_df['temp_avg'], width, label='Avg Temp (°C)', alpha=0.7)
axes[1].set_title('Past 5 Days Temperature (Bar Chart)')
axes[1].set_xlabel('Date')
axes[1].set_ylabel('Temperature (°C)')
axes[1].set_xticks(x)
axes[1].set_xticklabels(past_df['date'].dt.strftime('%Y-%m-%d'))
axes[1].legend()

plt.tight_layout()
plt.show()

# 2. 未来5天的气温变化 - 折线图
fig, ax = plt.subplots(figsize=(10, 6))

ax.plot(future_df['date'], future_df['temp_max'], label='Max Temp (°C)', marker='o')
ax.plot(future_df['date'], future_df['temp_min'], label='Min Temp (°C)', marker='o')
ax.plot(future_df['date'], future_df['temp_avg'], label='Avg Temp (°C)', marker='o')
ax.set_title('Next 5 Days Temperature (°C)')
ax.set_xlabel('Date')
ax.set_ylabel('Temperature (°C)')
ax.legend()

plt.show()

# 3. 今天的气温变化 - 箱线图（每3小时为单位）
fig, ax = plt.subplots(figsize=(10, 6))

# 绘制箱线图
ax.boxplot(today_df['temp'], vert=False, patch_artist=True, labels=['Avg Temp (°C)'])
ax.set_title('Today\'s Temperature (Boxplot)')
ax.set_xlabel('Temperature (°C)')
ax.set_ylabel('Time (3-Hour Intervals)')

plt.show()
