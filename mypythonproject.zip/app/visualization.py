import pandas as pd
import numpy as np
import io
import base64
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

def plot_pass(past_weather_data):
    if not past_weather_data:
        return None
    
    past_df = pd.DataFrame(past_weather_data)

    # Check if expected columns are in the data
    if 'Datetime' not in past_df.columns or 'Min Temperature (C)' not in past_df.columns:
        return None

    # 过去2天的气温变化 - 折线图和柱状图
    fig, axes = plt.subplots(2, 1, figsize=(10, 12))

    # 过去2天的折线图
    axes[0].plot(past_df['Datetime'], past_df['Min Temperature (C)'], label='Min Temp (°C)', marker='o')
    axes[0].plot(past_df['Datetime'], past_df['Max Temperature (C)'], label='Max Temp (°C)', marker='o')
    axes[0].plot(past_df['Datetime'], (past_df['Max Temperature (C)']+past_df['Min Temperature (C)'])/2, 
                 label='Avg Temp (°C)', marker='o')
    axes[0].set_title('Past Weather Temperature (°C)')
    axes[0].set_xlabel('Date')
    axes[0].set_ylabel('Temperature (°C)')
    axes[0].legend()

    # 过去2天的柱状图
    width = 0.2
    x = np.arange(len(past_df))
    axes[1].bar(x, past_df['Min Temperature (C)'], width, label='Min Temp (°C)', alpha=0.7)
    axes[1].bar(x - width, past_df['Max Temperature (C)'], width, label='Max Temp (°C)', alpha=0.7)
    axes[1].bar(x + width, (past_df['Max Temperature (C)']+past_df['Min Temperature (C)'])/2, 
                width, label='Avg Temp (°C)', alpha=0.7)
    axes[1].set_title('Past Weather Temperature (Bar Chart)')
    axes[1].set_xlabel('Date')
    axes[1].set_ylabel('Temperature (°C)')
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(past_df['Datetime'].dt.strftime('%Y-%m-%d'))
    axes[1].legend()

    img_io = io.BytesIO()
    plt.tight_layout()
    plt.savefig(img_io, format='png')
    img_io.seek(0)
    img_base64 = base64.b64encode(img_io.read()).decode('utf-8')
    plt.close(fig)

    return img_base64


def plot_future(future_weather_data):
    if not future_weather_data:
        return None
    
    future_df = pd.DataFrame(future_weather_data)

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(future_df['Datetime'], future_df['Min Temperature (C)'], label='Min Temp (°C)', marker='o')
    ax.plot(future_df['Datetime'], future_df['Max Temperature (C)'], label='Max Temp (°C)', marker='o')
    ax.plot(future_df['Datetime'], (future_df['Max Temperature (C)']+future_df['Min Temperature (C)'])/2, 
            label='Avg Temp (°C)', marker='o')
    ax.set_title('Future Weather Temperature (°C)')
    ax.set_xlabel('Date')
    ax.set_ylabel('Temperature (°C)')
    ax.legend()

    img_io = io.BytesIO()
    plt.savefig(img_io, format='png')
    img_io.seek(0)
    img_base64 = base64.b64encode(img_io.read()).decode('utf-8')
    plt.close(fig)

    return img_base64

def plot_now(today_weather_data):
    if not today_weather_data:
        return None
    
    today_df = pd.DataFrame([today_weather_data])

    fig, ax = plt.subplots(figsize=(10, 6))

    ax.boxplot(today_df['Temperature (C)'], vert=False, patch_artist=True, labels=['Avg Temp (°C)'])
    ax.set_title('Today\'s Temperature (Boxplot)')
    ax.set_xlabel('Temperature (°C)')
    ax.set_ylabel('Time (3-Hour Intervals)')

    img_io = io.BytesIO()
    plt.savefig(img_io, format='png')
    img_io.seek(0)
    img_base64 = base64.b64encode(img_io.read()).decode('utf-8')
    plt.close(fig)

    return img_base64