import requests
from flask import Flask, request, jsonify
from flask import Response
app = Flask(__name__)

def fetch_data(url):
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return data
    else:
        print(f"Failed to fetch data: {response.status_code}")
        return None


def fetch_weather_data(api_key, city):
    history_url = f'https://history.openweathermap.org/data/2.5/history/city?q={city}n&type=hour&appid={api_key}'
    history_data = fetch_data(history_url)

    
    current_url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}'
    current_data = fetch_data(current_url)

    forecast_url = f'http://api.openweathermap.org/data/2.5/forecast?q={city}&appid={api_key}'
    forecast_data = fetch_data(forecast_url)

    return history_data,current_data, forecast_data

import pandas as pd


def parse_weather(entry):

    if entry is None:
        return None
    return {
        'Datetime': pd.to_datetime(entry['dt'], unit='s'),
        'Temperature (C)': entry['main']['temp'] - 273.15,
        'Humidity (%)': entry['main']['humidity'],
        'Wind Speed (m/s)': entry['wind']['speed'],
        'Weather': entry['weather'][0]['description'],
    }


def save_to_csv(data, filename):

    if data is None:
        print(f"No data to save for {filename}")
        return
    df = pd.DataFrame(data)
    df.to_csv(filename, index=False)


def calculate_daily_stats(forecast_data):

    if forecast_data is None:
        return None

    df_forecast = pd.DataFrame(forecast_data)
    df_forecast['Date'] = df_forecast['Datetime'].dt.date

    daily_stats = df_forecast.groupby('Date').agg({
        'Temperature (C)': ['min', 'max'],
        'Humidity (%)': ['min', 'max'],
        'Wind Speed (m/s)': ['min', 'max']
    })

    daily_stats.columns = ['Min Temperature (C)', 'Max Temperature (C)', 
                           'Min Humidity (%)', 'Max Humidity (%)', 
                           'Min Wind Speed (m/s)', 'Max Wind Speed (m/s)']

    daily_stats.reset_index(inplace=True)

    return daily_stats


def process_weather_data(history_data,current_data, forecast_data):
    history_weather = [parse_weather(entry) for entry in history_data['list']]
    current_weather = parse_weather(current_data)
    forecast_weather = [parse_weather(entry) for entry in forecast_data['list']]

    save_to_csv(forecast_weather, 'history_hourly_weather_data.csv')
    save_to_csv([current_weather], 'current_weather_data.csv')
    save_to_csv(forecast_weather, 'forecast_hourly_weather_data.csv')


    history_daily_stats = calculate_daily_stats(history_weather)
    save_to_csv(history_daily_stats, 'history_daily_weather_stats.csv')
    forecast_daily_stats = calculate_daily_stats(forecast_weather)
    save_to_csv(forecast_daily_stats, 'forecast_daily_weather_stats.csv')

@app.route('/get_weather')
def get_weather():
    # 获取前端传递的城市名
    city = request.args.get('city')
    api_key = "c09f84c8b23339eea6c92eee24427d10"  # 使用实际的 API 密钥

    if city:
        # 调用 fetch_weather_data 函数获取天气数据
        weather_data = fetch_weather_data(api_key, city)
        a=process_weather_data(weather_data[0],weather_data[1],weather_data[2])
        return jsonify(weather_data) # 返回 JSON 格式的数据给前端
    else:
        return jsonify({"error": "City parameter is missing"}), 400


city = request.args.get('city')
api_key = "c09f84c8b23339eea6c92eee24427d10"
a=weather_data = fetch_weather_data(api_key, city)
process_weather_data(a[0],a[1],a[2])


