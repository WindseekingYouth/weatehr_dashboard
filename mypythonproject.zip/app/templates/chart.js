// 例子：当天的温度变化（折线图）
const ctx = document.getElementById('temperatureChart').getContext('2d');
const temperatureChart = new Chart(ctx, {
  type: 'line', // 折线图
  data: {
    labels: ['12AM', '3AM', '6AM', '9AM', '12PM', '3PM', '6PM', '9PM'], // X轴时间标签
    datasets: [
      {
        label: '最高温度',
        data: [22, 24, 26, 28, 30, 29, 27, 25], // 数据
        borderColor: 'red',
        backgroundColor: 'rgba(255, 0, 0, 0.2)',
        fill: true,
      },
      {
        label: '最低温度',
        data: [16, 17, 18, 19, 20, 21, 22, 21],
        borderColor: 'blue',
        backgroundColor: 'rgba(0, 0, 255, 0.2)',
        fill: true,
      },
      {
        label: '平均温度',
        data: [19, 20, 22, 24, 25, 25, 24, 23],
        borderColor: 'green',
        backgroundColor: 'rgba(0, 255, 0, 0.2)',
        fill: true,
      }
    ]
  },
  options: {
    responsive: true,
    scales: {
      x: {
        title: {
          display: true,
          text: '时间'
        }
      },
      y: {
        title: {
          display: true,
          text: '温度 (°C)'
        }
      }
    }
  }
});
